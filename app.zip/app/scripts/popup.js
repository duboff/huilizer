'use strict';

console.log('\'Allo \'Allo! Popup');
